GTPS server siap dijalankan di Railway.
Edit config.json untuk ubah pengaturan.