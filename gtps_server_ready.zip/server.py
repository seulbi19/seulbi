# Contoh server GTPS sederhana
print('GTPS Server is running...')